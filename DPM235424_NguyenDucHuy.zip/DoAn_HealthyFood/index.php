<?php
header("Location:public");
?>